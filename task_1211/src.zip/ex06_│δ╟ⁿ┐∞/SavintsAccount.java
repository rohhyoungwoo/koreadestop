package ex06_노형우;

public class SavintsAccount {

}
